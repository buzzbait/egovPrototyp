﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysoneModel.Utils
{
    class ColorTable
    {
        public static readonly string INDIGO_500 = "#3f51b5"; //MAIN
        public static readonly string INDIGO_50 = "#e8eaf6";
        public static readonly string INDIGO_100 = "#c5cae9";
    }
}
