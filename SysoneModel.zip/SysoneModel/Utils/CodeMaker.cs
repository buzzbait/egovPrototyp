﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysoneModel.Utils
{
    class CodeMaker
    {
        private static readonly string BASE_PACKAGE = "com.sysone.projectname.entity";

        private StringBuilder entityValue = new StringBuilder();
        private StringBuilder supportValue = new StringBuilder();
        private StringBuilder mapperValue = new StringBuilder();

        private DataTable table = null;
        private string tableName = null;

        public CodeMaker(DataTable table,string tableName)
        {
            this.table = table;
            this.tableName = tableName;
        }

        /* Entity DTO 만들기*/
        public void makeEntity()
        {
            entityValue.AppendLine(string.Format("/* {0}에 대한  Entity 입니다 */",tableName));

            entityValue.AppendLine(string.Empty);
            //패키지
            entityValue.AppendLine(string.Format("package {0}", BASE_PACKAGE));
            entityValue.AppendLine(string.Empty);

            entityValue.AppendLine("import java.sql.Timestamp");

            //롬복 지정
            entityValue.AppendLine(string.Format("@Getter", tableName));
            entityValue.AppendLine(string.Format("@Builder", tableName));
            
            entityValue.AppendLine(string.Format("public class {0}_Entity {{", tableName));
            entityValue.AppendLine(string.Empty);
            //멤버 지정
            foreach (DataRow row in table.Rows)
            {
                entityValue.AppendLine(string.Format("    private {0} {1};",StringUtil.convertEntityJavaType(row.Field<string>("DATA_TYPE")), StringUtil.convertUnderScoreToCamelCase(  row.Field<string>("COLUMN_NAME")) ) );
            }
            entityValue.AppendLine(string.Empty);
            entityValue.AppendLine("}");
        }

        public string getEntityValue()
        {
            return entityValue.ToString();
        }

        public void makeSupportObject()
        {
            supportValue.AppendLine(string.Format("/* {0}에 대한 Table Support 입니다 */", tableName));

            //패키지
            supportValue.AppendLine(string.Format("package {0}", BASE_PACKAGE));
            supportValue.AppendLine(string.Empty);
            //임포트
            supportValue.AppendLine("import java.sql.JDBCType");
            supportValue.AppendLine("import java.sql.Timestamp");
            supportValue.AppendLine("import org.mybatis.sql.SqlColumn");
            supportValue.AppendLine("import org.mybatis.sql.SqlTable");

            supportValue.AppendLine(string.Empty);

            //롬복 지정
            supportValue.AppendLine(string.Format("@Getter", tableName));
            supportValue.AppendLine(string.Format("@Builder", tableName));

            supportValue.AppendLine(string.Format("public final class {0}_TableSupport {{", tableName));
            supportValue.AppendLine(string.Empty);

            supportValue.AppendLine(string.Format("    public static final {0} {1} = new {2}();", tableName.ToUpper(), tableName.ToLower(), tableName.ToUpper()));

            //멤버 지정
            foreach (DataRow row in table.Rows)
            {
                string dataType = row.Field<string>("DATA_TYPE");
                string columnName = row.Field<string>("COLUMN_NAME");

                supportValue.AppendLine(string.Format("    public static final SqlColumn<{0}> {1} = {2}.{3};", 
                    StringUtil.convertSqlColumnType(dataType), 
                    StringUtil.convertUnderScoreToCamelCase(columnName) , 
                    tableName.ToLower(), 
                    StringUtil.convertUnderScoreToCamelCase(columnName) ));
            }
            supportValue.AppendLine(string.Empty);
            supportValue.AppendLine(string.Format("    public static final class {0} extends SqlTable {{ ", tableName.ToUpper()));
            supportValue.AppendLine(string.Empty);
            //멤버 지정
            foreach (DataRow row in table.Rows)
            {
                string dataType = row.Field<string>("DATA_TYPE");
                string columnName = row.Field<string>("COLUMN_NAME");

                supportValue.AppendLine(string.Format("         public final SqlColumn<{0}> {1} = column(\"{2}\",{3});",
                    StringUtil.convertSqlColumnType(dataType),
                    StringUtil.convertUnderScoreToCamelCase(columnName),
                    columnName.ToUpper(),
                    StringUtil.convertJdbcType(dataType)));
            }
            supportValue.AppendLine(string.Empty);
            supportValue.AppendLine(string.Format("         public {0}() {{", tableName.ToUpper()));
            supportValue.AppendLine(string.Format("             super(\"{0}\")", tableName.ToUpper()));
            supportValue.AppendLine("         }");
            supportValue.AppendLine(string.Empty);
            supportValue.AppendLine("    }");
            supportValue.AppendLine(string.Empty);
            supportValue.AppendLine("}");
        }

        public string getSupportObjectValue()
        {
            return supportValue.ToString();
        }

        public void makeMapper()
        {
            mapperValue.AppendLine(string.Format("/* {0}에 대한 Mapper 입니다 */", tableName));
            //패키지
            mapperValue.AppendLine(string.Format("package {0}", BASE_PACKAGE));
            mapperValue.AppendLine(string.Empty);

            //import


            mapperValue.AppendLine("@Mapper");
            mapperValue.AppendLine(string.Format("public interface {0}_Mapper {{",tableName ));
            mapperValue.AppendLine(string.Empty);

            /*SELECT 처리*/
            mapperValue.AppendLine(string.Format("    /* {0} 테이블 SELECT */", tableName));
            mapperValue.AppendLine("    @SelectProvider(type=SqlProviderAdapter.class, method=\"select\")");
            mapperValue.AppendLine(string.Format("    Optional<{0}_Entity> selectOne(SelectStatementProvider selectStatement)", tableName));
            mapperValue.AppendLine(string.Empty);

            string fieldList =  string.Join(",",table.AsEnumerable().Select(r => StringUtil.convertUnderScoreToCamelCase(r.Field<string>("COLUMN_NAME"))).ToArray()); 

            mapperValue.AppendLine(string.Format("    BasicColumn[] fieldList = BasicColumn.columnList({0})", fieldList));
            mapperValue.AppendLine(string.Empty);
            mapperValue.AppendLine(string.Format("    default Optional<{0}_Entity> selectOne(SelectDSLCompleter completer) {{", tableName));
            mapperValue.AppendLine(string.Format("        return MyBatisUtils.selectOne(this::selectOne,fieldList,{0},completer);", tableName.ToLower()));
            mapperValue.AppendLine("    }");
            mapperValue.AppendLine(string.Empty);

            /*INSERT처리*/
            mapperValue.AppendLine(string.Format("    /* {0} 테이블 INSERT */", tableName));
            mapperValue.AppendLine("    @InsertProvider(type=SqlProviderAdapter.class, method=\"insert\")");
            mapperValue.AppendLine(string.Format("    int insert(InsertStatementProvider<{0}_Entity> insertStatement)",tableName));
            mapperValue.AppendLine(string.Empty);
            mapperValue.AppendLine(string.Format("    default int insert({0}_Entity {1}Entity)", tableName.ToUpper(), tableName.ToLower()));
            mapperValue.AppendLine(string.Format("        return MyBatisUtils.insert(this::insert,{0}Entity,{1} , c ->", tableName.ToLower(), tableName.ToLower()));

            int i = 0;
            foreach (DataRow row in table.Rows)
            {
                string columnName = row.Field<string>("COLUMN_NAME");
                string mapValue = (i == 0) ? "            c.map({0}).toProperty(\"{1}\")" : "            .map({0}).toProperty(\"{1}\")";                
                mapperValue.AppendLine(string.Format(mapValue, columnName.ToLower(), columnName.ToLower()));
                i++;
            }

            mapperValue.AppendLine("        };");

            /* UPDATE 처리 */
            mapperValue.AppendLine(string.Format("    /* {0} 테이블 UPDATE */", tableName));
            mapperValue.AppendLine("    @UpdateProvider(type=SqlProviderAdapter.class, method=\"update\")");
            mapperValue.AppendLine("    int update(UpdateStatementProvider updateStatement)");
            mapperValue.AppendLine(string.Empty);
            mapperValue.AppendLine("    default int update(UpdateDslCompleter completer)");
            mapperValue.AppendLine(string.Format("        return MyBatisUtils.update(this::update,{0},completer )", tableName.ToLower()));
            mapperValue.AppendLine("    };");

            mapperValue.AppendLine(string.Empty);

            /* DELETE 처리 */
            mapperValue.AppendLine(string.Format("    /* {0} 테이블 DELETE */", tableName));
            mapperValue.AppendLine("    @DeleteProvider(type=SqlProviderAdapter.class, method=\"delete\")");
            mapperValue.AppendLine("    int delete(DeleteStatementProvider deleteStatement)");
            mapperValue.AppendLine(string.Empty);
            mapperValue.AppendLine("    default int delete(DeleteDslCompleter completer)");
            mapperValue.AppendLine(string.Format("        return MyBatisUtils.deleteFrom(this::delete,{0},completer )", tableName.ToLower()));
            mapperValue.AppendLine("    };");

            mapperValue.AppendLine(string.Empty);

            /* END */
            mapperValue.AppendLine("}");
            

        }

        public string getMapperValue()
        {
            return mapperValue.ToString();
        }
    }
}
