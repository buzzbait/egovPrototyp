﻿using Oracle.ManagedDataAccess.Client;
using SysoneModel.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysoneModel
{
    public partial class Form_Main : Form
    {
        public Form_Main()
        {
            InitializeComponent();
        }

        private void Form_Main_Load(object sender, EventArgs e)
        {
            this.initEnv();
        }

        private void initEnv()
        {
            this.panel_Top.BackColor = ColorTranslator.FromHtml(ColorTable.INDIGO_500);
            this.panel_Top_TableSpec.BackColor = ColorTranslator.FromHtml(ColorTable.INDIGO_100);
            setConnectionUI(false);
            CommonUtil.setDataGridView(this.dgv_Table);
            CommonUtil.setDataGridView(this.dgv_TableField );
            //databound
            this.dgv_Table.DataSource = this.ds_Main;
            this.dgv_Table.DataMember = "tbl_TableName";
            this.dgv_Table.Columns["COL_TABLE_NAME"].DataPropertyName = "TABLE_NAME";
            this.dgv_Table.Columns["COL_TABLE_NAME"].SortMode = DataGridViewColumnSortMode.NotSortable;
            this.dgv_Table.Columns["COL_TABLE_NAME"].Resizable = DataGridViewTriState.True;

            this.dgv_TableField.DataSource = this.ds_Main;
            this.dgv_TableField.DataMember = "tbl_FieldList";
            foreach (DataColumn dataColumn in this.ds_Main.Tables["tbl_FieldList"].Columns)
            {
                string columnName = dataColumn.ColumnName;

                this.dgv_TableField.Columns["COL_" + columnName].DataPropertyName = columnName;
                this.dgv_TableField.Columns["COL_" + columnName].SortMode = DataGridViewColumnSortMode.NotSortable;
                this.dgv_TableField.Columns["COL_" + columnName].Resizable = DataGridViewTriState.True;
            }            

            foreach(TabPage page in this.tab_Edit.TabPages) { page.Show(); }
        }

        private void btn_Connect_Click(object sender, EventArgs e)
        {
            this.connectServer();
        }

        private void connectServer()
        {
            string oraInfo = @"Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.105.4.51)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=G4FDEV)));User ID=EVISA;Password=EVISA01;Connection Timeout=30;";
            string errorInfo = OracleSession.connectServer(oraInfo);
            if (errorInfo == null)
            {
                setConnectionUI(true);                
                loadTableList();
            }
            else
            {
                setConnectionUI(false);
                MessageBox.Show(this, errorInfo, CommonConstants.APP_TITLE,  MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        //테이블 리스트 로딩
        private void loadTableList()
        {
            DataTable targetTable = this.ds_Main.Tables["tbl_TableName"];
            try
            {
                this.Cursor = Cursors.WaitCursor;                
                targetTable.BeginLoadData();
                targetTable.Rows.Clear();

                string query = "SELECT TABLE_NAME FROM Tabs";                
                using (OracleDataAdapter da = new OracleDataAdapter(query, OracleSession.getConnection()))
                {
                    da.Fill( this.ds_Main.Tables["tbl_TableName"]);                    

                }

                loadFieldList(0);
            }
            catch(Exception ex)
            {
                MessageBox.Show(this, ex.Message, CommonConstants.APP_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                targetTable.EndLoadData(); 
                this.Cursor = Cursors.Default;
            }

        }

        private void Form_Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            OracleSession.closeServer();
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            OracleSession.closeServer();
            ds_Main.Tables["tbl_TableName"].Rows.Clear();
            ds_Main.Tables["tbl_FieldList"].Rows.Clear();
            this.lbl_FieldList.Text = "테이블 필드 정의";
            setConnectionUI(false);            
        }

        //state(true) 연결된 상태
        private void setConnectionUI(bool isConnected)
        {
            pic_Online.Visible = isConnected;
            pic_Off.Visible = !isConnected;
            btn_Connect.Enabled = !isConnected;
            btn_Close.Enabled = isConnected;
            btn_MakeModel.Visible = isConnected;         
            this.status_Connect.Text =  (isConnected)? "연결됨" :"연결대기" ;
        }
        

        //필드명 로딩
        private void loadFieldList(int rowIndex)
        {
            string tableName = this.dgv_Table.Rows[rowIndex].Cells["COL_TABLE_NAME"].Value.ToString();
            DataTable targetTable = this.ds_Main.Tables["tbl_FieldList"];
            try
            {
                this.Cursor = Cursors.WaitCursor;
                targetTable.BeginLoadData();
                targetTable.Rows.Clear();

                string query = string.Format("SELECT COLUMN_NAME,DATA_TYPE FROM COLS WHERE TABLE_NAME = '{0}'",tableName);
                using (OracleDataAdapter da = new OracleDataAdapter(query, OracleSession.getConnection()))
                {
                    da.Fill(this.ds_Main.Tables["tbl_FieldList"]);
                }

                this.lbl_FieldList.Text = tableName + " : 필드정의"; 
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, CommonConstants.APP_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                targetTable.EndLoadData();
                this.Cursor = Cursors.Default;
            }
        }

        private void dgv_Table_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            loadFieldList(e.RowIndex);
        }

        private void btn_MakePojo_Click(object sender, EventArgs e)
        {
            if(ds_Main.Tables["tbl_TableName"].Rows.Count < 0)
            {
                MessageBox.Show(this, "테이블을 먼저 선택하세요!", CommonConstants.APP_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            makePojo();
        }

        private void makePojo()
        {
            int selectIndex = this.dgv_Table.SelectedRows[0].Index;
            string tableName = this.dgv_Table.Rows[selectIndex].Cells["COL_TABLE_NAME"].Value.ToString();

            CodeMaker codeMaker = new CodeMaker(ds_Main.Tables["tbl_FieldList"], tableName);
                        
            codeMaker.makeEntity();
            this.rtb_Pojo.Text = codeMaker.getEntityValue();
            MakerEditor.changeColor(rtb_Pojo);

                        
            codeMaker.makeSupportObject();
            this.rtb_Support.Text = codeMaker.getSupportObjectValue();
            MakerEditor.changeColor(rtb_Support);

            codeMaker.makeMapper();
            this.rtb_Mapper.Text = codeMaker.getMapperValue();
            MakerEditor.changeColor(rtb_Mapper);
            
        }
    }
}
